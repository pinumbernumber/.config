You will need to use a Windows port of GCC to build this.

I recommend TDM-GCC: http://tdm-gcc.tdragon.net/download

Then open a command window here and run build.bat